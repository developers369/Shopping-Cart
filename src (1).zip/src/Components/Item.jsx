import React, {useState} from 'react'

const Item = (props) => {

    const [isHover, setIsHover] = useState(false)


    const handleHover = () => {
        // alert(isHover)
        setIsHover(!isHover)
    }

    return (
        <div className="Item">
            <div className="imgContainer" onMouseOver={handleHover} onMouseOut={handleHover}>
                <img className={isHover === true ? "imgContainer iHover" : "imgContainer"} src={props.img} alt={props.name} />
                <i className={isHover === true ? "fa fa-search-plus search-plus itemImageHover" : "fa fa-search-plus search-plus"} aria-hidden="true" ></i>
            </div>

            <div className="itemText">
                <h2>{props.name}</h2>
                <p style={{fontSize : "20px"}}>This is a {props.name}</p>
                <b>${props.price}</b>
                <br></br>

                <button className="addToCartButton" onClick={props.onClick} >Add to Cart</button>
            </div>
        </div>
    )
}

export default Item